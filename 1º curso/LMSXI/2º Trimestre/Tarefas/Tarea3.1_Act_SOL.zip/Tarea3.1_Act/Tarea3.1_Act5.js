for ( var i = 1; i <= 3; i++ ) {
	do{	
			var a = parseInt ( prompt("Introduce un número: ") );
	
			if ( isNaN( a ) )
				  alert("ERROR! Debes introducir un valor numérico");
			else {	  
		          switch( a % 7 == 0 ){
	     						case true: alert(a + " es un número de tipo A!"); 
					 }

					 switch ( (a % 3 == 0) && (a < 0) ){
		  						case true: alert(a + " es un número de tipo B!");
			           			        break;
				   
		  						case false: switch( a % 7 != 0 ){
		  												 case true: alert(a + " es un número de tipo C!");
							        								   break;  
												}
					}
			}
	}while( isNaN( a ) );
}


alert("\n\nFin del programa!");

