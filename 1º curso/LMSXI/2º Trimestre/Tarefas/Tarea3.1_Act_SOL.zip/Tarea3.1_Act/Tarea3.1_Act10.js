do{
	var num = parseInt( prompt("Introduce un número") );
	
	if ( isNaN( num ) || num <= 0 || num > 25 )
		alert("ERROR. Debes introducir un número entre 1 y 25!");
}while ( isNaN( num ) || num <= 0 || num > 25 );

var fact = 1;

for ( var i = 2; i <= num; i++ )
	fact *= i;
	
document.write("\nEl Factorial de " + num + " es = " + fact );
