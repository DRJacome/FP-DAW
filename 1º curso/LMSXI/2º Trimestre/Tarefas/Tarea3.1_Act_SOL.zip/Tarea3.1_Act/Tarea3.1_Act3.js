
do{
	var radio = prompt("Introduce el valor del radio: ");

	if ( isNaN( radio ) || radio <= 0  )
		alert("ERROR. Debes introducir un valor numérico positivo!"); 

}while ( isNaN( radio ) || radio <= 0 );

document.write( "El Area de un círculo de Radio " 
					   + radio + " es " 
					   + ( Math.PI * Math.pow( parseFloat( radio ), 2 ) ).toFixed( 2 ) );
					  
