var dia, fechaOK, anho = (new Date).getFullYear();	

do{

	fechaOK = true;

	do{
		var dia = parseInt( prompt("Introduce el día: ") );
	
		if ( isNaN( dia ) || dia <= 0 || dia > 31 )
			alert("ERROR. Debes introducir un número entre 1 y 31!");
	}while ( isNaN( dia ) || dia <= 0 || dia > 31 );

	do{
		var mes = parseInt( prompt("Introduce el mes") );
	
		if ( isNaN( mes ) || mes <= 0 || mes > 12 )
			alert("ERROR. Debes introducir un número entre 1 y 12!");
	}while ( isNaN( mes ) || mes <= 0 || mes > 12 );


	if ( dia > 28 && mes == 2 )
		  fechaOK = false;
	else{
		if ( dia == 31 && ( mes != 1 || mes != 3 
		     || mes != 5 || mes != 7 || mes != 8 
		     || mes != 10 || mes != 12) )
		      fechaOK = false;
	}

	if ( !fechaOK )
		alert("La Fecha introducida -> " + dia + "/" + mes + "/" +
		      anho + " no es una fecha válida!")

}while ( !fechaOK );

document.write("\nFecha Introducida " + dia + "/" + mes + "/" +
 					 anho + "<br/>Horas restante hasta final de mes: ");

switch( mes ) {
	case 2: document.write( ( 28 - dia ) * 24 ); break;
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12: document.write( ( 31 - dia ) * 24 ); break;
	case 4:
	case 6:
	case 9:
	case 11: document.write( ( 30 - dia ) * 24 );
}

