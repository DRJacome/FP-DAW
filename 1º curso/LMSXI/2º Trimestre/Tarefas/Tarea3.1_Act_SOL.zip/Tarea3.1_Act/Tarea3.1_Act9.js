			const marca1 = "BMW", marca2 = "AUDI", marca3 = "VOLVO";
			const prec1 = 25000, prec2 = 30000, prec3 = 35000;
			const maxMens = 10;
			var numAnhos, marca, precioFinal;
			
			do{
				marca = prompt("\n MENÚ PRINCIPAL"
								+ "\n---------------------------------"
								+ "\n\n1. BMW"
								+ "\n\n2. AUDI"
								+ "\n\n3. MERCEDES"
								+ "\n\n---------------------------------"
								+ "\nSelecciona una marca: \n", "");
					
						if ( marca != '1' && marca != '2' && marca != '3' )
							alert( "ERROR. Opción no válida." );
						
			}while( marca != '1' && marca != '2' && marca != '3' );
			
			switch( marca ){
				case '1': precioFinal = prec1; break;
				case '2': precioFinal = prec2; break;
				case '3': precioFinal = prec3;
			}
			
			do{
				numAnhos = prompt( "Introduce un número años del pago", "Escribe" ); 
			
				if ( isNaN( numAnhos ) || numAnhos < 0 || numAnhos > maxMens )
					alert( "ERROR. Debes introducir un valor numérico positivo." );
			}while( isNaN( numAnhos ) || numAnhos < 0 || numAnhos > maxMens );
			
			document.write( "SELECCIÓN DE AUTO: " );
			document.write( "<BR /> - Marca: " );
			switch( marca ){
				case '1': document.write( marca1 ); 
						  document.write( "<br />- Precio: " + prec1 ); break;
				case '2': document.write( marca2 ); 
						  document.write( "<br />- Precio: " + prec2 ); break;
				case '3': document.write( marca3 ); 
						  document.write( "<br />- Precio: " + prec3 ); 
			}
			
			if ( numAnhos != 0 ){
				document.write( "<BR /> - Mensualidades pago: " + (numAnhos*12) );
				document.write( "<BR /> - Letra Mensual: " 
								+ parseFloat( precioFinal / (numAnhos*12) ).toFixed( 2 ) );
			}
			document.write( "<BR /> - PRECIO FINAL: " + precioFinal );						
