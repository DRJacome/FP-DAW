var mayor;

do{
	var n1 = parseFloat( prompt( "Introduce el primer número: " ) );
	var n2 = parseFloat( prompt( "Introduce el segundo número: " ) );
	var n3 = parseFloat( prompt( "Introduce el tercer número: " ) );

	if ( isNaN( n1 ) || isNaN( n2 ) || isNaN( n3 ) )
		 alert("ERROR. Debes introducir tres valores numéricos!"); 

}while ( isNaN( n1 ) || isNaN( n2 ) || isNaN( n3 ) );

if ( n1 >= n2 ){
	if ( n1 >= n3 )
		mayor = n1;
	else 
		mayor = n3;
}else{
	   if ( n2 >= n3 )
		       mayor = n2;
		    else 
			    mayor = n3;
}

document.write( "El número mayor entre " 
					 + n1 + " " + n2 + " y " + n3 + " es: " + mayor );  