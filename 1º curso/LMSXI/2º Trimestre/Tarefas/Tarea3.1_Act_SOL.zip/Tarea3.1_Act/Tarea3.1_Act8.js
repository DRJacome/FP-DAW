var a, b, mayor, menor;

do{
	a = prompt("Introduce num1: ");
	b = prompt("Introduce num2: ");
	
	if ( isNaN( a ) || isNaN( b ) )
		alert("ERROR! Debes introducir dos valores numéricos");
}while( isNaN( a ) || isNaN( b ) );

if ( a >= b ){
	mayor = a; 
	menor = b; 
}else{
	mayor = b;
	menor = a;
}

for ( var i = menor; i <= mayor; i++ )
		document.write( "<br/>" + i );


