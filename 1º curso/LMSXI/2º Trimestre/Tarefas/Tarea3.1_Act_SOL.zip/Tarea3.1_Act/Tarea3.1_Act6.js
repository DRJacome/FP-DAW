do{	
	var a = prompt("Introduce num1: ");
	if ( isNaN( a ) || a > 100 || a <= 0 )
		alert("ERROR! Debes introducir un número Natural menor a 100");
}while( isNaN( a ) || a > 100 || a <= 0 );

for ( var i = 0; i <= a; i++ )
		document.write( "\n" + i );






