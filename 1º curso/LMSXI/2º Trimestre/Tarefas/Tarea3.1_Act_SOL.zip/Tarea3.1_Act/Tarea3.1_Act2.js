
do{
	var n1 = parseFloat ( prompt("Introduce el primer número: ") );
	var n2 = parseFloat( prompt("Introduce el segundo número: ") );

	if ( isNaN( n1 ) || isNaN( n2 ) )
		alert("ERROR. Debes introducir dos valores numéricos!"); 

}while ( isNaN( n1 ) || isNaN( n2 ) );

document.write( "La suma de " + n1 + " 
                 + " + n2 + " es " + (n1 + n2) );
